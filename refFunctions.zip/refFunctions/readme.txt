reference Functions
--------------------