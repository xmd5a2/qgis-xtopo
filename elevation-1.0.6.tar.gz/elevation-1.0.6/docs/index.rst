
=========
elevation
=========

:Version: |release|
:Date: |today|

Easy access to global terrain digital elevation models, SRTM 30m DEM and SRTM 90m DEM.

If you have any feedback or you want to help out head over our main repository:
https://github.com/bopen/elevation

.. toctree::
    :maxdepth: 2
    :caption: Table of Contents

    quickstart
    design
